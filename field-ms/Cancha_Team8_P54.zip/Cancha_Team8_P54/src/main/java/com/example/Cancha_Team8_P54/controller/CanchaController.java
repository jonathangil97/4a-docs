package com.example.Cancha_Team8_P54.controller;


import lombok.AllArgsConstructor;
import com.example.Cancha_Team8_P54.model.Cancha;
import org.springframework.web.bind.annotation.*;
import com.example.Cancha_Team8_P54.services.CanchaService;

import java.util.List;

@CrossOrigin(origins= "*")
@RestController
@RequestMapping("/cancha")
@AllArgsConstructor

public class CanchaController {

    private final CanchaService canchaService;
    @GetMapping
    public List<Cancha> getAllCancha(){
        return canchaService.getAllCanchas();
    }

    @GetMapping("buscar_cancha")
    public List<Cancha> IndexCancha(){

        return canchaService.getAllCanchas();
    }

    @GetMapping("buscar_cancha/{direccion}")
    public Cancha buscar(@PathVariable String direccion){
        return canchaService.findCanchaDireccion(direccion);
    }

}
