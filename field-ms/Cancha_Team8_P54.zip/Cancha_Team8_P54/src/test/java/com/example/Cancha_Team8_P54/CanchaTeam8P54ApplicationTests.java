package com.example.Cancha_Team8_P54;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanchaTeam8P54ApplicationTests {

	@Test
	void contextLoads() {
	}

}
